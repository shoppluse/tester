"use client";

import { Book } from "@/types";
import { useState } from "react";

interface Props {
  books: Book[];
  selectedBookIds: string[];
  onToggleBook: (id: string) => void;
  onDeleteBook: (id: string) => void;
}

function formatSize(bytes: number) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export default function BookList({ books, selectedBookIds, onToggleBook, onDeleteBook }: Props) {
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (book: Book) => {
    if (!confirm(`Remove "${book.name}" from the library?`)) return;
    setDeletingId(book.id);
    try {
      await fetch(`/api/books/${book.id}`, { method: "DELETE" });
      onDeleteBook(book.id);
    } catch (e) {
      console.error(e);
    } finally {
      setDeletingId(null);
    }
  };

  if (books.length === 0) {
    return (
      <div className="text-center py-8" style={{ color: "var(--text-muted)" }}>
        <div className="text-3xl mb-2 opacity-30">📚</div>
        <p className="text-xs">No books uploaded yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between mb-1">
        <span className="text-xs" style={{ color: "var(--text-muted)" }}>
          {selectedBookIds.length === 0
            ? "All books (searching all)"
            : `${selectedBookIds.length} selected`}
        </span>
        {books.length > 1 && (
          <button
            onClick={() => books.forEach((b) => !selectedBookIds.includes(b.id) && onToggleBook(b.id))}
            className="text-xs hover:underline"
            style={{ color: "var(--accent-gold)" }}
          >
            Select all
          </button>
        )}
      </div>
      {books.map((book) => {
        const isSelected = selectedBookIds.includes(book.id);
        const isDeleting = deletingId === book.id;
        return (
          <div
            key={book.id}
            className={`rounded-lg p-3 border transition-all ${
              isSelected ? "border-yellow-700/50" : "border-stone-800/50"
            }`}
            style={{
              background: isSelected ? "rgba(212,168,67,0.06)" : "rgba(22,18,9,0.5)",
            }}
          >
            <div className="flex items-start gap-2">
              <button
                onClick={() => onToggleBook(book.id)}
                className={`mt-0.5 w-4 h-4 rounded border flex-shrink-0 flex items-center justify-center transition-all ${
                  isSelected ? "border-yellow-600 bg-yellow-600/20" : "border-stone-700"
                }`}
              >
                {isSelected && (
                  <svg width="8" height="8" viewBox="0 0 8 8" fill="none">
                    <path d="M1 4L3 6L7 2" stroke="#d4a843" strokeWidth="1.5" strokeLinecap="round" />
                  </svg>
                )}
              </button>
              <div className="flex-1 min-w-0">
                <p
                  className="text-sm font-medium truncate leading-tight"
                  style={{ color: "var(--text-primary)", fontFamily: "'Playfair Display', serif" }}
                  title={book.name}
                >
                  {book.name}
                </p>
                <p className="text-xs mt-0.5" style={{ color: "var(--text-muted)" }}>
                  {book.pageCount} pages · {book.chunkCount} sections · {formatSize(book.size)}
                </p>
              </div>
              <button
                onClick={() => handleDelete(book)}
                disabled={isDeleting}
                className="text-stone-700 hover:text-red-500 transition-colors flex-shrink-0 text-xs p-0.5"
                title="Remove book"
              >
                {isDeleting ? "…" : "✕"}
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
