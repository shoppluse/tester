"use client";

import { ChatMessage as ChatMessageType } from "@/types";
import ReactMarkdown from "react-markdown";
import SourceCards from "./SourceCards";

interface Props {
  message: ChatMessageType;
}

export default function ChatMessage({ message }: Props) {
  const isUser = message.role === "user";

  if (isUser) {
    return (
      <div className="message-enter flex justify-end">
        <div
          className="max-w-[75%] rounded-2xl rounded-tr-sm px-4 py-3"
          style={{
            background: "linear-gradient(135deg, rgba(196,131,42,0.15), rgba(212,168,67,0.1))",
            border: "1px solid rgba(212,168,67,0.2)",
          }}
        >
          <p className="text-sm leading-relaxed" style={{ color: "var(--text-primary)" }}>
            {message.content}
          </p>
          <p className="text-xs mt-1.5 text-right" style={{ color: "var(--text-muted)" }}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="message-enter flex justify-start">
      <div className="max-w-[88%] w-full">
        <div className="flex items-center gap-2 mb-2">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-sm"
            style={{ background: "rgba(212,168,67,0.1)", border: "1px solid rgba(212,168,67,0.2)" }}
          >
            📜
          </div>
          <span className="text-xs font-medium" style={{ color: "var(--accent-gold)" }}>
            Oracle
          </span>
          <span className="text-xs" style={{ color: "var(--text-muted)" }}>
            {new Date(message.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
          </span>
        </div>

        {message.isSearching ? (
          <div
            className="rounded-2xl rounded-tl-sm px-4 py-4 border"
            style={{ background: "rgba(22,18,9,0.6)", borderColor: "rgba(90,66,10,0.2)" }}
          >
            <div className="flex items-center gap-3">
              <div className="flex gap-1.5">
                <span className="typing-dot" />
                <span className="typing-dot" />
                <span className="typing-dot" />
              </div>
              <span className="text-xs" style={{ color: "var(--text-muted)" }}>
                Searching through sacred texts…
              </span>
            </div>
          </div>
        ) : (
          <div
            className="rounded-2xl rounded-tl-sm px-4 py-4 border"
            style={{
              background: "rgba(22,18,9,0.6)",
              borderColor: "rgba(90,66,10,0.2)",
            }}
          >
            <div className="prose-sacred text-sm">
              <ReactMarkdown>{message.content}</ReactMarkdown>
            </div>

            {message.sources && message.sources.length > 0 && (
              <SourceCards sources={message.sources} />
            )}

            {message.sources && message.sources.length === 0 && (
              <div
                className="mt-3 flex items-center gap-2 text-xs py-2 px-3 rounded-lg"
                style={{
                  background: "rgba(255,100,50,0.06)",
                  border: "1px solid rgba(255,100,50,0.15)",
                  color: "rgba(255,150,100,0.8)",
                }}
              >
                <span>⚠</span>
                <span>No matching passages found in the uploaded books.</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
