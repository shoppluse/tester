"use client";

import { useCallback, useState } from "react";
import { useDropzone } from "react-dropzone";
import { Book } from "@/types";

interface Props {
  onBookUploaded: (book: Book) => void;
}

export default function BookUploader({ onBookUploaded }: Props) {
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const onDrop = useCallback(
    async (acceptedFiles: File[]) => {
      const file = acceptedFiles[0];
      if (!file) return;

      setUploading(true);
      setMessage(null);

      const formData = new FormData();
      formData.append("file", file);

      try {
        const res = await fetch("/api/upload", { method: "POST", body: formData });
        const data = await res.json();

        if (!res.ok) {
          setMessage({ text: data.error || "Upload failed", type: "error" });
        } else {
          setMessage({ text: data.message, type: "success" });
          onBookUploaded(data.book);
        }
      } catch {
        setMessage({ text: "Network error. Please try again.", type: "error" });
      } finally {
        setUploading(false);
      }
    },
    [onBookUploaded]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { "application/pdf": [".pdf"] },
    maxFiles: 1,
    disabled: uploading,
  });

  return (
    <div className="space-y-3">
      <div
        {...getRootProps()}
        className={`drop-zone border-2 border-dashed rounded-xl p-6 text-center cursor-pointer transition-all
          ${isDragActive ? "active border-yellow-600/60" : "border-stone-700/50 hover:border-yellow-700/40"}
          ${uploading ? "opacity-50 cursor-not-allowed" : ""}`}
        style={{ background: isDragActive ? "rgba(212,168,67,0.04)" : "rgba(22,18,9,0.4)" }}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center gap-2">
          {uploading ? (
            <>
              <div className="w-10 h-10 rounded-full border-2 border-yellow-600/30 border-t-yellow-600 animate-spin" />
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Processing PDF…
              </p>
            </>
          ) : (
            <>
              <div
                className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                style={{ background: "rgba(212,168,67,0.08)", border: "1px solid rgba(212,168,67,0.15)" }}
              >
                📖
              </div>
              <div>
                <p className="text-sm font-medium" style={{ color: "var(--text-primary)" }}>
                  {isDragActive ? "Drop your book here" : "Upload a PDF Book"}
                </p>
                <p className="text-xs mt-1" style={{ color: "var(--text-muted)" }}>
                  Drag & drop or click to browse
                </p>
              </div>
            </>
          )}
        </div>
      </div>

      {message && (
        <div
          className={`rounded-lg p-3 text-sm ${
            message.type === "success"
              ? "bg-emerald-950/50 border border-emerald-800/30 text-emerald-400"
              : "bg-red-950/50 border border-red-800/30 text-red-400"
          }`}
        >
          {message.text}
        </div>
      )}
    </div>
  );
}
