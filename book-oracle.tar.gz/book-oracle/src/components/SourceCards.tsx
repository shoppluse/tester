"use client";

import { SourceReference } from "@/types";

interface Props {
  sources: SourceReference[];
}

export default function SourceCards({ sources }: Props) {
  if (!sources || sources.length === 0) return null;

  return (
    <div className="mt-4 space-y-2">
      <div className="flex items-center gap-2 ornament">
        <span
          className="text-xs font-medium px-2 whitespace-nowrap"
          style={{ color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace" }}
        >
          Sources
        </span>
      </div>
      <div className="grid gap-2">
        {sources.map((src, i) => (
          <div
            key={i}
            className="source-card rounded-lg p-3 border"
            style={{
              background: "rgba(16,12,6,0.6)",
              borderColor: "rgba(90,66,10,0.25)",
            }}
          >
            <div className="flex items-start justify-between gap-2 mb-2">
              <div className="flex items-center gap-2">
                <div
                  className="w-5 h-5 rounded flex items-center justify-center text-xs font-bold flex-shrink-0"
                  style={{
                    background: "rgba(212,168,67,0.12)",
                    color: "var(--accent-gold)",
                    fontFamily: "'JetBrains Mono', monospace",
                  }}
                >
                  {i + 1}
                </div>
                <div>
                  <p
                    className="text-xs font-semibold leading-tight"
                    style={{ color: "var(--accent-amber)", fontFamily: "'Playfair Display', serif" }}
                  >
                    {src.bookName}
                  </p>
                  <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                    Page {src.pageNumber}
                    {src.chunkIndex !== undefined && ` · Section ${src.chunkIndex + 1}`}
                  </p>
                </div>
              </div>
              <div
                className="text-xs px-2 py-0.5 rounded-full flex-shrink-0"
                style={{
                  background: "rgba(212,168,67,0.08)",
                  color: "var(--accent-gold)",
                  fontFamily: "'JetBrains Mono', monospace",
                }}
              >
                {Math.round(src.similarity * 100)}% match
              </div>
            </div>
            <blockquote
              className="text-xs leading-relaxed pl-3 italic"
              style={{
                color: "var(--text-secondary)",
                borderLeft: "2px solid rgba(212,168,67,0.2)",
              }}
            >
              "{src.relevantText.slice(0, 280)}{src.relevantText.length > 280 ? "…" : ""}"
            </blockquote>
          </div>
        ))}
      </div>
    </div>
  );
}
