export interface Book {
  id: string;
  name: string;
  fileName: string;
  uploadedAt: string;
  pageCount: number;
  chunkCount: number;
  size: number;
}

export interface TextChunk {
  id: string;
  bookId: string;
  bookName: string;
  text: string;
  pageNumber: number;
  chunkIndex: number;
  embedding?: number[];
}

export interface SearchResult {
  chunk: TextChunk;
  similarity: number;
  relevantText: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  sources?: SourceReference[];
  timestamp: string;
  isSearching?: boolean;
}

export interface SourceReference {
  bookName: string;
  pageNumber: number;
  chunkIndex: number;
  relevantText: string;
  similarity: number;
}

export interface BookStore {
  books: Book[];
  chunks: TextChunk[];
}
