import { TextChunk, BookStore } from "@/types";
import { v4 as uuidv4 } from "uuid";
import fs from "fs";
import path from "path";

const STORE_PATH = path.join(process.cwd(), "data", "store.json");

function ensureDataDir() {
  const dir = path.join(process.cwd(), "data");
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

export function loadStore(): BookStore {
  ensureDataDir();
  if (!fs.existsSync(STORE_PATH)) return { books: [], chunks: [] };
  try {
    return JSON.parse(fs.readFileSync(STORE_PATH, "utf-8"));
  } catch {
    return { books: [], chunks: [] };
  }
}

export function saveStore(store: BookStore) {
  ensureDataDir();
  fs.writeFileSync(STORE_PATH, JSON.stringify(store, null, 2));
}

// Simple but effective TF-IDF-style embedding using term frequency vectors
// This avoids OpenAI API costs while still doing semantic search
function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length > 2);
}

// Stop words to filter
const STOP_WORDS = new Set([
  "the", "and", "for", "are", "but", "not", "you", "all", "can", "her",
  "was", "one", "our", "out", "day", "get", "has", "him", "his", "how",
  "man", "new", "now", "old", "see", "two", "way", "who", "boy", "did",
  "its", "let", "put", "say", "she", "too", "use", "that", "this", "with",
  "have", "from", "they", "will", "been", "had", "have", "more", "when",
  "than", "into", "then", "some", "what", "also", "which", "their", "there",
  "would", "could", "should", "about", "being", "those", "these", "other",
  "from", "your", "just", "like", "well", "even", "back", "any", "good",
  "know", "come", "over", "think", "also", "here", "very", "much", "such"
]);

function getSignificantTerms(text: string): Map<string, number> {
  const tokens = tokenize(text).filter((t) => !STOP_WORDS.has(t));
  const freq = new Map<string, number>();
  for (const token of tokens) {
    freq.set(token, (freq.get(token) || 0) + 1);
  }
  return freq;
}

export function computeEmbedding(text: string): number[] {
  // Create a consistent vocabulary-based sparse vector
  const terms = getSignificantTerms(text);
  // Use a hash-based approach to create a dense vector
  const DIM = 512;
  const vec = new Array(DIM).fill(0);
  for (const [term, freq] of terms) {
    // Hash the term to multiple positions for better coverage
    for (let i = 0; i < 3; i++) {
      let hash = 0;
      const salt = `${i}_${term}`;
      for (let j = 0; j < salt.length; j++) {
        hash = ((hash << 5) - hash + salt.charCodeAt(j)) | 0;
      }
      const idx = Math.abs(hash) % DIM;
      vec[idx] += freq * Math.log(1 + freq);
    }
  }
  // Normalize
  const magnitude = Math.sqrt(vec.reduce((sum, v) => sum + v * v, 0));
  if (magnitude > 0) return vec.map((v) => v / magnitude);
  return vec;
}

export function cosineSimilarity(a: number[], b: number[]): number {
  if (!a || !b || a.length !== b.length) return 0;
  let dot = 0;
  for (let i = 0; i < a.length; i++) dot += a[i] * b[i];
  return Math.max(0, dot);
}

export function chunkText(text: string, bookId: string, bookName: string): TextChunk[] {
  const chunks: TextChunk[] = [];
  const CHUNK_SIZE = 600;
  const OVERLAP = 100;

  // Split by pages first (pdf-parse adds page markers sometimes)
  const pagePattern = /\f/g;
  const pages = text.split(pagePattern);

  let globalChunkIndex = 0;

  pages.forEach((pageText, pageIndex) => {
    const words = pageText.split(/\s+/).filter(Boolean);
    if (words.length < 10) return;

    let start = 0;
    while (start < words.length) {
      const end = Math.min(start + CHUNK_SIZE, words.length);
      const chunkWords = words.slice(start, end);
      const chunkText = chunkWords.join(" ");

      if (chunkText.trim().length > 50) {
        const embedding = computeEmbedding(chunkText);
        chunks.push({
          id: uuidv4(),
          bookId,
          bookName,
          text: chunkText,
          pageNumber: pageIndex + 1,
          chunkIndex: globalChunkIndex++,
          embedding,
        });
      }

      start += CHUNK_SIZE - OVERLAP;
    }
  });

  return chunks;
}

export function searchChunks(query: string, chunks: TextChunk[], topK = 5): Array<{ chunk: TextChunk; similarity: number }> {
  const queryEmbedding = computeEmbedding(query);
  const queryTerms = getSignificantTerms(query);

  const scored = chunks.map((chunk) => {
    const embeddingSim = chunk.embedding ? cosineSimilarity(queryEmbedding, chunk.embedding) : 0;

    // Boost with keyword matching for exact terms
    let keywordBoost = 0;
    const chunkLower = chunk.text.toLowerCase();
    for (const [term] of queryTerms) {
      if (chunkLower.includes(term)) keywordBoost += 0.05;
    }

    return { chunk, similarity: Math.min(1, embeddingSim + keywordBoost) };
  });

  return scored
    .filter((r) => r.similarity > 0.01)
    .sort((a, b) => b.similarity - a.similarity)
    .slice(0, topK);
}

export function extractRelevantPassage(chunk: TextChunk, query: string): string {
  const queryTerms = getSignificantTerms(query);
  const sentences = chunk.text.split(/[.!?]+/).filter((s) => s.trim().length > 20);

  // Score each sentence by query term overlap
  const scored = sentences.map((sentence) => {
    const sentLower = sentence.toLowerCase();
    let score = 0;
    for (const [term] of queryTerms) {
      if (sentLower.includes(term)) score++;
    }
    return { sentence, score };
  });

  const topSentences = scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .map((s) => s.sentence.trim());

  if (topSentences.length === 0) return chunk.text.slice(0, 400) + "...";
  return topSentences.join(". ") + ".";
}
