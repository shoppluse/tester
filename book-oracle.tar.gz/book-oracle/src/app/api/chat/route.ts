import { NextRequest, NextResponse } from "next/server";
import { loadStore, searchChunks, extractRelevantPassage } from "@/lib/vectorStore";
import { SourceReference } from "@/types";
import Anthropic from "@anthropic-ai/sdk";
// @ts-ignore

export const runtime = "nodejs";
export const maxDuration = 60;

const client = new Anthropic();

export async function POST(request: NextRequest) {
  try {
    const { question, bookIds } = await request.json();

    if (!question || question.trim().length === 0) {
      return NextResponse.json({ error: "Question is required" }, { status: 400 });
    }

    const store = loadStore();

    if (store.books.length === 0) {
      return NextResponse.json({
        answer: "No books have been uploaded yet. Please upload a PDF book first before asking questions.",
        sources: [],
        found: false,
      });
    }

    // Filter chunks by selected books if specified
    let searchableChunks = store.chunks;
    if (bookIds && bookIds.length > 0) {
      searchableChunks = store.chunks.filter((c) => bookIds.includes(c.bookId));
    }

    if (searchableChunks.length === 0) {
      return NextResponse.json({
        answer: "No content found in selected books. Please check your book selection.",
        sources: [],
        found: false,
      });
    }

    // Search for relevant passages
    const results = searchChunks(question, searchableChunks, 8);

    if (results.length === 0 || results[0].similarity < 0.02) {
      return NextResponse.json({
        answer:
          "No relevant answer found in the uploaded books. The books do not appear to contain information directly related to your question.",
        sources: [],
        found: false,
      });
    }

    // Take top 5 most relevant results
    const topResults = results.slice(0, 5);

    // Build context from retrieved passages
    const contextPassages = topResults.map((r, i) => {
      const book = store.books.find((b) => b.id === r.chunk.bookId);
      return `[Passage ${i + 1} - ${r.chunk.bookName}, Page ${r.chunk.pageNumber}]\n${r.chunk.text}`;
    });

    const context = contextPassages.join("\n\n---\n\n");

    // Use Claude to synthesize the answer from retrieved passages ONLY
    const systemPrompt = `You are a sacred text interpreter and book scholar. Your ONLY job is to answer questions using the provided book passages.

CRITICAL RULES:
1. Answer ONLY using the provided passages below — never use your general knowledge
2. If the passages contain relevant information, synthesize a clear, insightful answer
3. Quote or paraphrase directly from the passages
4. Always reference which passage you're drawing from
5. If the passages don't contain relevant information, say: "The uploaded books do not contain a direct answer to this question."
6. Never add external information, speculation, or general AI knowledge
7. Keep the spiritual/philosophical tone of the source material
8. Format your answer in clear paragraphs, using markdown for structure

The passages below are your ONLY source of truth. Answer as if you have read only these books and nothing else.`;

    const userPrompt = `Question: "${question}"

Here are the relevant passages from the uploaded books:

${context}

Based ONLY on these passages, provide a thoughtful and comprehensive answer. Reference the specific passages and page numbers in your answer.`;

    const response = await client.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1024,
      system: systemPrompt,
      messages: [{ role: "user", content: userPrompt }],
    });

    const answer = response.content[0].type === "text" ? response.content[0].text : "Unable to generate answer.";

    // Check if Claude found it unanswerable
    const notFound =
      answer.toLowerCase().includes("do not contain") ||
      answer.toLowerCase().includes("not contain a direct") ||
      answer.toLowerCase().includes("cannot find");

    // Build source references
    const sources: SourceReference[] = topResults.slice(0, 4).map((r) => ({
      bookName: r.chunk.bookName,
      pageNumber: r.chunk.pageNumber,
      chunkIndex: r.chunk.chunkIndex,
      relevantText: extractRelevantPassage(r.chunk, question),
      similarity: r.similarity,
    }));

    return NextResponse.json({
      answer,
      sources: notFound ? [] : sources,
      found: !notFound,
    });
  } catch (error) {
    console.error("Chat error:", error);
    return NextResponse.json(
      { error: "Failed to search books. Please try again." },
      { status: 500 }
    );
  }
}
