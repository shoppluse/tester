import { NextRequest, NextResponse } from "next/server";
import { v4 as uuidv4 } from "uuid";
import { loadStore, saveStore, chunkText } from "@/lib/vectorStore";
import { Book } from "@/types";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";
export const maxDuration = 60;

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const file = formData.get("file") as File;

    if (!file) {
      return NextResponse.json({ error: "No file provided" }, { status: 400 });
    }

    if (!file.name.toLowerCase().endsWith(".pdf")) {
      return NextResponse.json({ error: "Only PDF files are supported" }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Dynamically import pdf-parse to avoid issues
    const pdfParse = (await import("pdf-parse")).default;
    const pdfData = await pdfParse(buffer);

    const text = pdfData.text;
    const pageCount = pdfData.numpages;

    if (!text || text.trim().length < 100) {
      return NextResponse.json(
        { error: "Could not extract text from PDF. The file may be scanned or image-based." },
        { status: 400 }
      );
    }

    const store = loadStore();

    // Check for duplicates
    const existingBook = store.books.find((b) => b.fileName === file.name);
    if (existingBook) {
      return NextResponse.json(
        { error: `Book "${file.name}" is already uploaded.` },
        { status: 409 }
      );
    }

    const bookId = uuidv4();
    const chunks = chunkText(text, bookId, file.name.replace(".pdf", ""));

    const book: Book = {
      id: bookId,
      name: file.name.replace(".pdf", "").replace(/-/g, " ").replace(/_/g, " "),
      fileName: file.name,
      uploadedAt: new Date().toISOString(),
      pageCount,
      chunkCount: chunks.length,
      size: buffer.byteLength,
    };

    store.books.push(book);
    store.chunks.push(...chunks);
    saveStore(store);

    // Save PDF file for reference
    const uploadsDir = path.join(process.cwd(), "data", "uploads");
    if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
    fs.writeFileSync(path.join(uploadsDir, file.name), buffer);

    return NextResponse.json({
      success: true,
      book,
      message: `Successfully processed "${book.name}" — ${chunks.length} text sections indexed from ${pageCount} pages.`,
    });
  } catch (error) {
    console.error("Upload error:", error);
    return NextResponse.json(
      { error: "Failed to process PDF. Please try again." },
      { status: 500 }
    );
  }
}

export async function GET() {
  try {
    const store = loadStore();
    return NextResponse.json({ books: store.books });
  } catch {
    return NextResponse.json({ books: [] });
  }
}
