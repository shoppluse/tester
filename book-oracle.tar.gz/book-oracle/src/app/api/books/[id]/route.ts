import { NextRequest, NextResponse } from "next/server";
import { loadStore, saveStore } from "@/lib/vectorStore";
import fs from "fs";
import path from "path";

export const runtime = "nodejs";

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const { id } = params;
    const store = loadStore();

    const book = store.books.find((b) => b.id === id);
    if (!book) {
      return NextResponse.json({ error: "Book not found" }, { status: 404 });
    }

    // Remove book and its chunks
    store.books = store.books.filter((b) => b.id !== id);
    store.chunks = store.chunks.filter((c) => c.bookId !== id);
    saveStore(store);

    // Delete the PDF file
    const filePath = path.join(process.cwd(), "data", "uploads", book.fileName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }

    return NextResponse.json({ success: true, message: `"${book.name}" removed successfully.` });
  } catch (error) {
    console.error("Delete error:", error);
    return NextResponse.json({ error: "Failed to delete book" }, { status: 500 });
  }
}
