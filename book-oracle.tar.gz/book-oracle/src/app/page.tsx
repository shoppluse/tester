"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import { v4 as uuidv4 } from "uuid";
import BookUploader from "@/components/BookUploader";
import BookList from "@/components/BookList";
import ChatMessage from "@/components/ChatMessage";
import { Book, ChatMessage as ChatMessageType } from "@/types";

const WELCOME: ChatMessageType = {
  id: "welcome",
  role: "assistant",
  content: `Welcome to **Book Oracle** — your personal sacred text intelligence.

Upload any PDF book using the panel on the left, then ask me anything. I will search through your books and answer **only** from what is written within them.

*I do not speculate. I do not draw from outside knowledge. I am bound entirely to the texts you provide.*

**To begin:** Upload a PDF book, then ask your first question.`,
  sources: undefined,
  timestamp: new Date().toISOString(),
};

export default function Home() {
  const [books, setBooks] = useState<Book[]>([]);
  const [selectedBookIds, setSelectedBookIds] = useState<string[]>([]);
  const [messages, setMessages] = useState<ChatMessageType[]>([WELCOME]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Load books on mount
  useEffect(() => {
    fetch("/api/upload")
      .then((r) => r.json())
      .then((d) => setBooks(d.books || []))
      .catch(() => {});
  }, []);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleBookUploaded = useCallback((book: Book) => {
    setBooks((prev) => [...prev, book]);
  }, []);

  const handleToggleBook = useCallback((id: string) => {
    setSelectedBookIds((prev) =>
      prev.includes(id) ? prev.filter((b) => b !== id) : [...prev, id]
    );
  }, []);

  const handleDeleteBook = useCallback((id: string) => {
    setBooks((prev) => prev.filter((b) => b.id !== id));
    setSelectedBookIds((prev) => prev.filter((b) => b !== id));
  }, []);

  const handleSubmit = async () => {
    const question = input.trim();
    if (!question || isLoading) return;

    setInput("");
    setIsLoading(true);

    const userMsg: ChatMessageType = {
      id: uuidv4(),
      role: "user",
      content: question,
      timestamp: new Date().toISOString(),
    };

    const loadingMsg: ChatMessageType = {
      id: uuidv4(),
      role: "assistant",
      content: "",
      isSearching: true,
      timestamp: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMsg, loadingMsg]);

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          bookIds: selectedBookIds.length > 0 ? selectedBookIds : null,
        }),
      });

      const data = await res.json();

      const assistantMsg: ChatMessageType = {
        id: uuidv4(),
        role: "assistant",
        content: data.error || data.answer || "An unexpected error occurred.",
        sources: data.sources || [],
        timestamp: new Date().toISOString(),
      };

      setMessages((prev) => [...prev.slice(0, -1), assistantMsg]);
    } catch {
      setMessages((prev) => [
        ...prev.slice(0, -1),
        {
          id: uuidv4(),
          role: "assistant",
          content: "Connection error. Please try again.",
          sources: [],
          timestamp: new Date().toISOString(),
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  const clearChat = () => {
    setMessages([WELCOME]);
  };

  return (
    <div className="flex h-screen overflow-hidden" style={{ position: "relative", zIndex: 1 }}>
      {/* Sidebar */}
      <aside
        className={`flex-shrink-0 flex flex-col border-r transition-all duration-300 overflow-hidden
          ${sidebarOpen ? "w-72" : "w-0"}`}
        style={{
          borderColor: "var(--border)",
          background: "rgba(10,8,4,0.95)",
        }}
      >
        <div className="flex flex-col h-full overflow-hidden" style={{ minWidth: "288px" }}>
          {/* Logo */}
          <div className="p-5 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center gap-3">
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center text-xl float-animate"
                style={{
                  background: "radial-gradient(circle, rgba(212,168,67,0.15), rgba(212,168,67,0.03))",
                  border: "1px solid rgba(212,168,67,0.25)",
                  boxShadow: "0 0 15px rgba(212,168,67,0.1)",
                }}
              >
                🔮
              </div>
              <div>
                <h1
                  className="text-base font-bold leading-tight"
                  style={{
                    fontFamily: "'Playfair Display', serif",
                    background: "linear-gradient(135deg, #d4a843, #e8c57a)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                  }}
                >
                  Book Oracle
                </h1>
                <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                  Sacred Text Intelligence
                </p>
              </div>
            </div>
          </div>

          {/* Upload section */}
          <div className="p-4 border-b" style={{ borderColor: "var(--border)" }}>
            <div className="flex items-center justify-between mb-3">
              <h2
                className="text-xs font-semibold uppercase tracking-widest"
                style={{ color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace" }}
              >
                Add Books
              </h2>
            </div>
            <BookUploader onBookUploaded={handleBookUploaded} />
          </div>

          {/* Book list */}
          <div className="flex-1 overflow-y-auto p-4">
            <div className="flex items-center justify-between mb-3">
              <h2
                className="text-xs font-semibold uppercase tracking-widest"
                style={{ color: "var(--text-muted)", fontFamily: "'JetBrains Mono', monospace" }}
              >
                Library ({books.length})
              </h2>
            </div>
            <BookList
              books={books}
              selectedBookIds={selectedBookIds}
              onToggleBook={handleToggleBook}
              onDeleteBook={handleDeleteBook}
            />
          </div>

          {/* Footer */}
          <div className="p-4 border-t" style={{ borderColor: "var(--border)" }}>
            <p className="text-xs leading-relaxed" style={{ color: "var(--text-muted)" }}>
              Answers come exclusively from uploaded books. No external knowledge is used.
            </p>
          </div>
        </div>
      </aside>

      {/* Main chat area */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Header */}
        <header
          className="flex items-center justify-between px-4 py-3 border-b flex-shrink-0"
          style={{ borderColor: "var(--border)", background: "rgba(10,8,4,0.8)" }}
        >
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen((p) => !p)}
              className="p-2 rounded-lg transition-colors hover:bg-white/5"
              style={{ color: "var(--text-muted)" }}
            >
              <svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor">
                <rect y="2" width="16" height="1.5" rx="1" />
                <rect y="7.25" width="16" height="1.5" rx="1" />
                <rect y="12.5" width="16" height="1.5" rx="1" />
              </svg>
            </button>
            <div>
              <h2
                className="text-sm font-semibold"
                style={{ fontFamily: "'Playfair Display', serif", color: "var(--text-primary)" }}
              >
                {selectedBookIds.length === 0
                  ? "All Books"
                  : `${selectedBookIds.length} Book${selectedBookIds.length > 1 ? "s" : ""} Selected`}
              </h2>
              {books.length > 0 && (
                <p className="text-xs" style={{ color: "var(--text-muted)" }}>
                  {books.reduce((a, b) => a + b.chunkCount, 0).toLocaleString()} passages indexed
                </p>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2">
            {messages.length > 1 && (
              <button
                onClick={clearChat}
                className="text-xs px-3 py-1.5 rounded-lg border transition-all hover:border-yellow-700/40"
                style={{
                  color: "var(--text-muted)",
                  borderColor: "var(--border)",
                  background: "transparent",
                }}
              >
                Clear chat
              </button>
            )}
          </div>
        </header>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-6 space-y-6">
          <div className="max-w-3xl mx-auto space-y-6">
            {messages.map((msg) => (
              <ChatMessage key={msg.id} message={msg} />
            ))}
            <div ref={messagesEndRef} />
          </div>
        </div>

        {/* Empty state when no books */}
        {books.length === 0 && messages.length === 1 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="text-center max-w-xs">
              <div
                className="text-6xl mx-auto mb-4 w-24 h-24 rounded-full flex items-center justify-center float-animate"
                style={{
                  background: "radial-gradient(circle, rgba(212,168,67,0.08), transparent)",
                  border: "1px solid rgba(212,168,67,0.1)",
                }}
              >
                📚
              </div>
              <h3
                className="text-lg font-semibold mb-2"
                style={{ fontFamily: "'Playfair Display', serif", color: "var(--text-secondary)" }}
              >
                Begin with a Book
              </h3>
              <p className="text-sm" style={{ color: "var(--text-muted)" }}>
                Upload a PDF from the sidebar to start querying its wisdom.
              </p>
            </div>
          </div>
        )}

        {/* Input area */}
        <div
          className="flex-shrink-0 px-4 pb-4 pt-3 border-t"
          style={{ borderColor: "var(--border)", background: "rgba(10,8,4,0.9)" }}
        >
          <div className="max-w-3xl mx-auto">
            <div
              className="flex items-end gap-3 rounded-2xl px-4 py-3 border transition-all"
              style={{
                background: "rgba(22,18,9,0.8)",
                borderColor: isLoading ? "rgba(212,168,67,0.3)" : "rgba(90,66,10,0.3)",
                boxShadow: isLoading ? "0 0 15px rgba(212,168,67,0.08)" : "none",
              }}
            >
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={
                  books.length === 0
                    ? "Upload a PDF book to begin asking questions…"
                    : "Ask anything from your books… (Enter to send)"
                }
                disabled={isLoading || books.length === 0}
                rows={1}
                className="flex-1 bg-transparent border-none outline-none resize-none text-sm leading-relaxed"
                style={{
                  color: "var(--text-primary)",
                  maxHeight: "120px",
                  minHeight: "24px",
                  caretColor: "var(--accent-gold)",
                  fontFamily: "'DM Sans', sans-serif",
                }}
                onInput={(e) => {
                  const t = e.currentTarget;
                  t.style.height = "auto";
                  t.style.height = Math.min(t.scrollHeight, 120) + "px";
                }}
              />
              <button
                onClick={handleSubmit}
                disabled={isLoading || !input.trim() || books.length === 0}
                className="btn-gold rounded-xl px-4 py-2 text-sm flex-shrink-0 flex items-center gap-1.5"
                style={{ fontFamily: "'DM Sans', sans-serif" }}
              >
                {isLoading ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-stone-800/50 border-t-stone-800 rounded-full animate-spin" />
                    <span>Seeking…</span>
                  </>
                ) : (
                  <>
                    <span>Ask</span>
                    <svg width="14" height="14" viewBox="0 0 14 14" fill="currentColor">
                      <path d="M1 7h12M8 2l5 5-5 5" stroke="currentColor" strokeWidth="1.5" fill="none" strokeLinecap="round" strokeLinejoin="round" />
                    </svg>
                  </>
                )}
              </button>
            </div>
            <p className="text-center text-xs mt-2" style={{ color: "var(--text-muted)" }}>
              Answers are sourced exclusively from uploaded books — no external knowledge
            </p>
          </div>
        </div>
      </main>
    </div>
  );
}
