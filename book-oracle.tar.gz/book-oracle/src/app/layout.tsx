import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Book Oracle — Sacred Text Intelligence",
  description: "Ask questions and receive answers only from your uploaded books and PDFs",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
