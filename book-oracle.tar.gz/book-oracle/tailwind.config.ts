import type { Config } from "tailwindcss";
const config: Config = {
  content: ["./src/pages/**/*.{js,ts,jsx,tsx,mdx}", "./src/components/**/*.{js,ts,jsx,tsx,mdx}", "./src/app/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      fontFamily: {
        serif: ["'Playfair Display'", "Georgia", "serif"],
        sans: ["'DM Sans'", "sans-serif"],
        mono: ["'JetBrains Mono'", "monospace"],
      },
      colors: {
        parchment: { 50: "#fdf8f0", 100: "#f9edd8", 200: "#f3d9a8", 300: "#eac075", 400: "#e0a245", 500: "#d4882a", 600: "#b8701f", 700: "#8f551a", 800: "#6d411a", 900: "#4d2f15" },
        ink: { 50: "#f0f0f0", 100: "#d9d9d9", 200: "#b3b3b3", 300: "#808080", 400: "#595959", 500: "#333333", 600: "#1a1a1a", 700: "#0d0d0d", 800: "#080808", 900: "#030303" },
        scripture: { DEFAULT: "#8B6914", light: "#C49A35", dark: "#5A420A" }
      },
      animation: {
        "pulse-slow": "pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "shimmer": "shimmer 2s linear infinite",
        "float": "float 6s ease-in-out infinite",
      },
      keyframes: {
        shimmer: { "0%": { backgroundPosition: "-200% 0" }, "100%": { backgroundPosition: "200% 0" } },
        float: { "0%, 100%": { transform: "translateY(0px)" }, "50%": { transform: "translateY(-10px)" } }
      }
    },
  },
  plugins: [],
};
export default config;
