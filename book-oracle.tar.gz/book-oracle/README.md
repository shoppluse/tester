# 📖 Book Oracle — Sacred Text Intelligence System

A production-ready, full-stack AI application that answers questions **exclusively** from your uploaded PDF books — no hallucinations, no external knowledge, only the texts you provide.

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 📤 **PDF Upload** | Drag-and-drop or click to upload any PDF book |
| 🔍 **Semantic Search** | Hash-based vector embeddings for intelligent passage retrieval |
| 🤖 **AI Synthesis** | Claude synthesizes coherent answers from retrieved passages only |
| 📌 **Source References** | Every answer shows exact book, page number, and matching passage |
| 📚 **Multi-Book Support** | Upload and search across multiple books simultaneously |
| 🎯 **Book Filtering** | Selectively search specific books from your library |
| 🚫 **Zero Hallucination** | System prompt strictly bounds Claude to uploaded content only |
| 🗑️ **Book Management** | Delete books and their indexed content anytime |
| 🌑 **Dark Mode UI** | Elegant dark design with gold accents |
| 📱 **Responsive** | Works on desktop, tablet, and mobile |

---

## 🏗️ Architecture

```
User Question
     │
     ▼
┌─────────────┐
│  Next.js 14 │  — App Router + TypeScript
└──────┬──────┘
       │
  ┌────┴────┐
  │  Chat   │  POST /api/chat
  │  API    │
  └────┬────┘
       │
       ▼
┌─────────────────┐
│  Vector Store   │  — Local JSON file (data/store.json)
│  (TF-IDF Hash   │
│   Embeddings)   │
└────────┬────────┘
         │  Top 5 relevant passages
         ▼
┌─────────────────┐
│  Claude Sonnet  │  — Answers ONLY from retrieved passages
│  (Constrained)  │
└─────────────────┘
         │
         ▼
Answer + Source References
```

### Search Pipeline
1. **Upload**: PDF parsed with `pdf-parse`, text extracted page by page
2. **Chunking**: Text split into ~600-word overlapping chunks
3. **Embedding**: Each chunk hashed into 512-dim vector (term frequency × IDF weighting)
4. **Query**: User question converted to same vector space
5. **Retrieval**: Cosine similarity + keyword boost → top 5 chunks
6. **Synthesis**: Claude Sonnet generates answer ONLY from retrieved passages
7. **Attribution**: Source book + page number returned for every answer

---

## 🚀 Quick Start

### Prerequisites
- Node.js 18+
- npm or yarn
- Anthropic API key

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/your-username/book-oracle.git
cd book-oracle

# 2. Install dependencies
npm install

# 3. Set up environment
cp .env.example .env.local
# Edit .env.local and add your ANTHROPIC_API_KEY

# 4. Run in development
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) and start uploading books!

---

## 📁 Project Structure

```
book-oracle/
├── src/
│   ├── app/
│   │   ├── api/
│   │   │   ├── upload/route.ts       # PDF upload & text extraction
│   │   │   ├── chat/route.ts         # Question answering endpoint
│   │   │   └── books/[id]/route.ts   # Book deletion
│   │   ├── globals.css               # Design system & styles
│   │   ├── layout.tsx                # Root layout
│   │   └── page.tsx                  # Main application UI
│   ├── components/
│   │   ├── BookUploader.tsx          # Drag-and-drop PDF uploader
│   │   ├── BookList.tsx              # Library with filter selection
│   │   ├── ChatMessage.tsx           # Message rendering with markdown
│   │   └── SourceCards.tsx           # Source reference display
│   ├── lib/
│   │   └── vectorStore.ts            # Embeddings, search, chunking logic
│   └── types/
│       └── index.ts                  # TypeScript interfaces
├── data/                             # Created at runtime
│   ├── store.json                    # Vector store (books + embeddings)
│   └── uploads/                      # Uploaded PDF files
├── .env.example                      # Environment template
├── .env.local                        # Your actual env (not committed)
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── next.config.js
```

---

## 🔧 Configuration

### Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `ANTHROPIC_API_KEY` | ✅ Yes | Your Anthropic API key |
| `NEXT_PUBLIC_APP_URL` | No | Your deployment URL |

### Tuning Search Quality

In `src/lib/vectorStore.ts`:

```typescript
// Chunk size (words per chunk) — larger = more context, less precision
const CHUNK_SIZE = 600;

// Overlap between chunks — prevents missing answers at boundaries
const OVERLAP = 100;

// Number of top chunks to retrieve
const topK = 5; // in searchChunks()

// Vector dimensions — higher = more precise but slower
const DIM = 512;
```

---

## 🚢 Deployment

### Vercel (Recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variable in Vercel dashboard:
# ANTHROPIC_API_KEY = your-key
```

> **Important**: The local `data/` directory is ephemeral on Vercel. For production, replace the JSON file store with a database (Postgres, Redis) or object storage (S3, R2).

### Railway / Render

Works out of the box — the `data/` directory persists on platforms with persistent storage. Set `ANTHROPIC_API_KEY` in the environment variables.

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

```bash
docker build -t book-oracle .
docker run -p 3000:3000 -e ANTHROPIC_API_KEY=your-key -v $(pwd)/data:/app/data book-oracle
```

---

## 🔒 How "No Hallucination" Works

The system uses a **two-layer constraint**:

1. **Retrieval layer**: Only text chunks from uploaded PDFs are retrieved — no outside text enters the pipeline.

2. **Prompt constraint**: Claude is given this system prompt:
   ```
   Answer ONLY using the provided passages below — never use your general knowledge.
   If the passages don't contain relevant information, say: "The uploaded books do not 
   contain a direct answer to this question."
   ```

3. **Fallback detection**: If Claude's answer contains "do not contain" or "cannot find", the UI displays a "no results" indicator and suppresses source cards.

---

## 📚 Example Use Cases

| Book | Question | What Happens |
|------|----------|-------------|
| Bhagavad Gita | "How do I control my mind?" | Finds verses on mind-control, cites chapter/page |
| Stoic Philosophy | "What should I do when I'm angry?" | Returns Stoic passages on anger management |
| Medical Textbook | "What are the symptoms of diabetes?" | Extracts clinical definition from the text |
| History Book | "What caused WWI?" | Finds the relevant historical passages |

---

## 🛠️ Tech Stack

| Layer | Technology |
|-------|-----------|
| Frontend | Next.js 14, React 18, TypeScript |
| Styling | Tailwind CSS, custom CSS (dark theme) |
| AI | Anthropic Claude Sonnet (synthesis) |
| Search | Custom TF-IDF hash embeddings + cosine similarity |
| Storage | Local JSON file store (swappable for any DB) |
| PDF Parsing | `pdf-parse` (Node.js) |
| UI Components | `react-dropzone`, `react-markdown`, `lucide-react` |

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Commit changes: `git commit -m 'Add my feature'`
4. Push: `git push origin feature/my-feature`
5. Open a Pull Request

---

## 📄 License

MIT License — see LICENSE file for details.

---

*Built with care. Answers only what the books say.*
